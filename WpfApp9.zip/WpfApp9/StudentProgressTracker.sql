-- Step 1: Create the database
CREATE DATABASE StudentProgressTracker;
GO

-- Step 2: Use the newly created database
USE StudentProgressTracker;
GO

-- Step 3: Create the Students table
CREATE TABLE Students (
    StudentId INT IDENTITY(1,1) PRIMARY KEY,  -- Auto-incremented ID for each student
    Name NVARCHAR(100),                        -- Student's Name
    Grade CHAR(1),                             -- Student's Grade (A, B, C, etc.)
    Subject NVARCHAR(100),                     -- Subject of the student
    Marks INT,                                 -- Marks scored by the student
    Attendance DECIMAL(5, 2)                   -- Attendance percentage
);
GO

-- Step 4: Insert multiple students into the Students table
INSERT INTO Students (Name, Grade, Subject, Marks, Attendance)
VALUES 
('John Doe', 'A', 'Math', 85, 90.00),
('Jane Smith', 'B', 'Science', 75, 80.00),
('Mark Johnson', 'C', 'History', 70, 85.00),
('Emily Davis', 'A', 'English', 95, 100.00),
('Michael Brown', 'B', 'Physics', 80, 88.00),
('Sarah Wilson', 'A', 'Biology', 92, 95.00),
('David Martinez', 'C', 'Chemistry', 65, 75.00),
('Laura Lee', 'B', 'Math', 78, 85.00),
('James Taylor', 'A', 'Computer Science', 90, 92.00),
('Linda Anderson', 'B', 'Geography', 82, 89.00);
GO
SELECT * FROM Students;
